/* Generated automatically. */
static const char configuration_arguments[] = "/mnt/ssd/jenkins_iotsw/slave/workspace/Toolchain/build-gnu-csky_4/source//gcc/configure x86_64-linux  --enable-languages=c,c++ --disable-threads --enable-sjlj-exceptions --disable-shared --disable-libssp --target=csky-elf-noneabiv2 --prefix=/mnt/ssd/jenkins_iotsw/slave/workspace/Toolchain/build-gnu-csky_4/install/ --with-headers=/mnt/ssd/jenkins_iotsw/slave/workspace/Toolchain/build-gnu-csky_4/install//csky-elf-noneabiv2/include --with-lib=/mnt/ssd/jenkins_iotsw/slave/workspace/Toolchain/build-gnu-csky_4/install//csky-elf-noneabiv2/lib/ --with-mpfr=/mnt/ssd/jenkins_iotsw/slave/workspace/Toolchain/build-gnu-csky_4/lib-for-gcc-x86_64-linux/ --with-gmp=/mnt/ssd/jenkins_iotsw/slave/workspace/Toolchain/build-gnu-csky_4/lib-for-gcc-x86_64-linux/ --with-mpc=/mnt/ssd/jenkins_iotsw/slave/workspace/Toolchain/build-gnu-csky_4/lib-for-gcc-x86_64-linux/ --with-cskyabi=abiv2 --with-pkgversion='Xuantie-800 Tools V3.10.33 Newlib abiv2 B20250328' --with-newlib";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { NULL, NULL} };
